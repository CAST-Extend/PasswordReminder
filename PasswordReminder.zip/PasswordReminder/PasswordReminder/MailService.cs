﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Configuration;

namespace PasswordReminder
{
    public static class MailService
    {
        public static void WriteErrorLog(Exception ex)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", true);
                sw.WriteLine(DateTime.Now.ToString() + ": " + ex.Source.ToString().Trim() + "; " + ex.Message.ToString().Trim());
                sw.Flush();
                sw.Close();
            }
            catch
            {

            }
        }
        public static void WriteErrorLog(string Message)
        {
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt",true);
                sw.WriteLine(DateTime.Now.ToString() + ": " + Message);                
                sw.Flush();
                sw.Close();
            }
            catch
            {
            }
        }

        //public static void SendEmail(string acnt,int pwdexp,string ToEmail, string CC, string subjct, string bodyMessage)
        public static void SendEmail(string acnt,string userName, int pwdexp, string ToEmail, string CC)
        {
            try
            {

                string FromEmailid = ConfigurationManager.AppSettings["FromMail"].ToString();
                string Pass = ConfigurationManager.AppSettings["Password"].ToString();
                string port = ConfigurationManager.AppSettings["Port"].ToString();
                string Host = ConfigurationManager.AppSettings["Host"].ToString();
                string mailmsg = ConfigurationManager.AppSettings["MailMsg1"].ToString();
                string mailmseg = ConfigurationManager.AppSettings["MailMsg2"].ToString();
                string mailmsg3 = ConfigurationManager.AppSettings["MailMsg3"].ToString();
                string mailmsg4 = ConfigurationManager.AppSettings["MailMsg4"].ToString();
                string sub = ConfigurationManager.AppSettings["Subject"].ToString();

                string bodyMessage = "<p>Hello " + userName + ",<p/><p>" + mailmsg + " [" + acnt + "] for user [" + userName + "] " + mailmsg4 + "</p><p>" + mailmseg + "</p><p>" + mailmsg3 + "</p><p>Thank you,</p>Administrator<p></>";
                //creating the object of MailMessage  

                MailMessage mailMessage = new MailMessage();
                System.Net.Mime.ContentType HTMLType = new System.Net.Mime.ContentType("text/html");
                mailMessage.BodyEncoding = System.Text.Encoding.Default;
                mailMessage.To.Add(ToEmail);
                mailMessage.From = new MailAddress(FromEmailid); //From Email Id  
                if (pwdexp > 1)
                {
                    mailMessage.Subject = "Attention ! | " + acnt + " - " + userName + " | " + sub; //+ pwdexp + " days"; //Subject of Email  
                    //mailMessage.Subject = "IMPORTANT | " + acnt + " - " + userName + " | " + sub + pwdexp + " days"; //Subject of Email  
                }
                else
                {
                    mailMessage.Subject = "Attention ! | " + acnt + " - " + userName + " | " + sub;// +pwdexp + " day"; //Subject of Email 
                }
                mailMessage.Body = bodyMessage; //body or message of Email 
                mailMessage.IsBodyHtml = true;
                System.Net.Mail.AlternateView HTMLView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(bodyMessage, HTMLType);



                //string[] ToMuliId = ToEmail.Split(',');
                //foreach (string ToEMailId in ToMuliId)
                //{
                //    mailMessage.To.Add(new MailAddress(ToEMailId)); //adding multiple TO Email Id  
                //}
                string[] CCId = CC.Split(',');

                foreach (string CCEmail in CCId)
                {
                    mailMessage.CC.Add(new MailAddress(CCEmail.Trim())); //Adding Multiple CC email Id  
                }

                //string[] bccid = bcc.Split(',');

                //foreach (string bccEmailId in bccid)
                //{
                //    mailMessage.Bcc.Add(new MailAddress(bccEmailId)); //Adding Multiple BCC email Id  
                //}
                SmtpClient smtp = new SmtpClient();  // creating object of smptpclient 
                smtp.EnableSsl = true;
                smtp.Timeout = 2000000;
                smtp.Host = Host;              //host of emailaddress for example smtp.gmail.com etc  

                //network and security related credentials  

                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential();
                NetworkCred.UserName = mailMessage.From.Address;
                NetworkCred.Password = Pass;
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = Convert.ToInt32(port);
                //smtp.Send(mailMessage); //sending Email  
                WriteErrorLog("Mail has been successfully sent to User--->" + userName + "---on mail id---" + ToEmail + " for account--->" + acnt );
            }
            catch (Exception ex)
            {
                string msg = ex.InnerException.Message;
                WriteErrorLog(msg);
                WriteErrorLog(ex.InnerException.Message);
                throw;
            }

        }

    }
}
