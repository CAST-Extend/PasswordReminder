﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;

namespace PasswordReminder
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DataTable dt = new DataTable();
                //MailService.WriteErrorLog("ServiceTimer_Tick Function Executing-----");
                string exlSheet=ConfigurationManager.AppSettings["exlSheet"].ToString();
                int rwCount = 0, colCount = 0, expPwd = 0;
                string acc = string.Empty, usrEmail = string.Empty, usrName = string.Empty, mgrEmail = string.Empty, emailQAmgr = string.Empty;
                //string fname = Path.GetFullPath("EngagementLevelPasswordResetDetails1.xlsx");
                //string filePath1 = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
                //var GetDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);  
                string filePath = System.AppDomain.CurrentDomain.BaseDirectory.ToString() + "\\" + exlSheet;
                MailService.WriteErrorLog("Reading Excel File from--->" + filePath);
                dt = ReadAsDataTable(filePath);

                rwCount = dt.Rows.Count;
                colCount = dt.Columns.Count;
                int expday = 0;
                emailQAmgr = ConfigurationManager.AppSettings["POC_prsn"].ToString();
                int pwdrmday=Convert.ToInt16(ConfigurationManager.AppSettings["PwdRemDay"].ToString());
                foreach (DataRow rw in dt.Rows)
                {
                    if (!string.IsNullOrEmpty(rw["Account"].ToString()))
                    {
                        acc = rw["Account"].ToString();

                    }
                    if (!string.IsNullOrEmpty(rw["UserEmailID"].ToString()))
                    {
                        usrEmail = rw["UserEmailID"].ToString();

                    }
                    if (!string.IsNullOrEmpty(rw["UserName"].ToString()))
                    {
                        usrName = rw["UserName"].ToString();

                    }
                    if (!string.IsNullOrEmpty(rw["ManagerEmailID"].ToString()))
                    {
                        mgrEmail = rw["ManagerEmailID"].ToString();

                    }
                    if (!string.IsNullOrEmpty(rw["PasswordExpiryDays"].ToString()))
                    {
                        expPwd = Convert.ToInt16(rw["PasswordExpiryDays"]);
                        DateTime curdate=DateTime.Now.Date;
                        int curday = curdate.Day;
                        expday = expPwd - curday;

                    }
                   
                    //if ((expday <= pwdrmday || expday==0) &&(!string.IsNullOrEmpty(acc) && !string.IsNullOrEmpty(usrName) && !string.IsNullOrEmpty(usrEmail) && !string.IsNullOrEmpty(mgrEmail) && !string.IsNullOrEmpty(emailQAmgr)))
                    if ((expday <= pwdrmday || expday == 0) && (!string.IsNullOrEmpty(acc) && !string.IsNullOrEmpty(usrName) && !string.IsNullOrEmpty(usrEmail) && !string.IsNullOrEmpty(emailQAmgr)))
                    {
                        //MailService.SendEmail(acc,usrName, expday, usrEmail, mgrEmail + "," + emailQAmgr);
                        MailService.SendEmail(acc,usrName, expday, usrEmail, mgrEmail + "," + emailQAmgr);
                        acc="";
                        usrName="";
                        usrEmail="";
                        mgrEmail="";
                    }

                    //MailService.SendEmail(acc, expday,usrEmail, mgrEmail + "," + emailQAmgr, "Reg: Password Update going to expire ", "Your pasword going to expire, Kindly update your password");
                }


                
            }
            catch (Exception ex)
            {
                MailService.WriteErrorLog("Got the Error--->" + ex.Message);
            }
            }




        public static DataTable ReadAsDataTable(string fileName)
        {
            DataTable dataTable = new DataTable();
            try
            {

                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(fileName, false))
                {
                    WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;
                    IEnumerable<Sheet> sheets = spreadsheetDocument.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>();
                    string relationshipId = sheets.First().Id.Value;
                    WorksheetPart worksheetPart = (WorksheetPart)spreadsheetDocument.WorkbookPart.GetPartById(relationshipId);
                    //WorksheetPart worksheetPart = workbookPart.WorksheetParts.First();
                    Worksheet workSheet = worksheetPart.Worksheet;
                    SheetData sheetData = workSheet.GetFirstChild<SheetData>();
                    IEnumerable<Row> rows = sheetData.Descendants<Row>();
                    
                    
                    
                    //SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                    foreach (Cell cell in rows.ElementAt(0))
                    {
                        dataTable.Columns.Add(GetCellValue(spreadsheetDocument, cell));
                    }

                    foreach (Row row in rows)
                    {
                            DataRow dataRow = dataTable.NewRow();
                            for (int i = 0; i < row.Descendants<Cell>().Count(); i++)
                            {
                                Cell cell = row.Descendants<Cell>().ElementAt(i);
                                int actualCellIndex = CellReferenceToIndex(cell);
                                dataRow[actualCellIndex] = GetCellValue(spreadsheetDocument, cell);
                            }
                            //for (int i = 0; i < row.Descendants<Cell>().Count(); i++)
                            //{
                            //    dataRow[i] = GetCellValue(spreadsheetDocument, row.Descendants<Cell>().ElementAt(i));
                            //}

                            dataTable.Rows.Add(dataRow);
                        
                    }
                   
                }

                dataTable.Rows.RemoveAt(0);
                return dataTable;

            }

            catch (Exception ex)
            {
                MailService.WriteErrorLog("Got the error--->" + ex.Message);
            }
            return dataTable;
        }

        private static int CellReferenceToIndex(Cell cell)
        {
            int index = 0;
            string reference = cell.CellReference.ToString().ToUpper();
            foreach (char ch in reference)
            {
                if (Char.IsLetter(ch))
                {
                    int value = (int)ch - (int)'A';
                    index = (index == 0) ? value : ((index + 1) * 26) + value;
                }
                else
                    return index;
            }
            return index;
        }


        private static string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            if (cell == null || cell.ChildElements.Count == 0)
            {
                return null;

            }
           
            string value=string.Empty;
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if(cell.InnerText!=null)
            {
                value = cell.CellValue.InnerXml;
            
           

                if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
                {
                    return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
                }
                else
                {
                    return value;
                }
                
            }
            return value;
        }

    }
}
